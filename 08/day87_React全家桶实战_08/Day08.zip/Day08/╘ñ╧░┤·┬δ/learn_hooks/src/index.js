import React from 'react';
import ReactDOM from 'react-dom/client';
// import App from './01_hooks体验/App';
// import App from "./02_effect/App"
// import App from "./03_context/App"
// import App from "./04_reducer/App"
// import App from "./05_callback/App"
// import App from "./06_memo/App"
import App from "./07_ref/App"
import { UserContext, ThemeContext } from "./context"

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <UserContext.Provider value={{name: "why", age: 18}}>
    <ThemeContext.Provider value={{color: "blue", size: 30}}>
      <App />
    </ThemeContext.Provider>
  </UserContext.Provider>
);

