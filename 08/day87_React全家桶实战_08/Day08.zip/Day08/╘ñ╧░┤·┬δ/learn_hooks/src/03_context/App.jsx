import React, { useContext } from 'react'
import { ThemeContext, UserContext } from '../context'

function App() {
  const theme = useContext(ThemeContext)
  const user = useContext(UserContext)

  return (
    <div>App: {user.name}-{user.age}:{theme.color}-{theme.size}</div>
  )
}

export default App