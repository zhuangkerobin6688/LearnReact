import React, { useEffect, useRef, useState } from 'react'

function App() {
  const [count, setCount] = useState()
  const value = useRef("哈哈哈")
  
  useEffect(() => {
    setTimeout(() => {
      value.current = "呵呵呵"
    }, 1000);
  }, [])

  return (
    <div>
      <h2>{value.current}</h2>
      <button onClick={e => setCount(count + 1)}>+1</button>
    </div>
  )
}

export default App