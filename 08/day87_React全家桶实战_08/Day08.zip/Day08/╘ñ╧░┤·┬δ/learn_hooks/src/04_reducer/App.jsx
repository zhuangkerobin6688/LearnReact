import React, { useReducer } from 'react'

function counterReducer(state, action) {
  switch(action.type) {
    case "add_number":
      return {...state, counter: state.counter + action.num}
    case "sub_number":
      return {...state, counter: state.counter - action.num}
    default:
      return state
  }
}

function App() {
  const [state, dispatch] = useReducer(counterReducer, { counter: 1 })

  return (
    <div>
      <h2>state:{state.counter}</h2>
      <button onClick={e => dispatch({type: "add_number", num: 10})}>+10</button>
      <button onClick={e => dispatch({type: "sub_number", num: 10})}>-10</button>
    </div>
  )
}

export default App