import React from 'react';
import ReactDOM from 'react-dom/client';
// import App from './01_不使用Hook/App';
// import App from "./02_计时器实现对比/App"
import App from "./03_useState的使用/App"

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  // <React.StrictMode>
    <App />
  // </React.StrictMode>
);