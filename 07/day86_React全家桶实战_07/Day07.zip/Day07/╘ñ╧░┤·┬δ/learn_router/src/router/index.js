import React from "react";
import { Navigate } from "react-router-dom";
import About from "../pages/About";
import Detail from "../pages/Detail";
import Home from "../pages/Home";
import Login from "../pages/Login";
import NotFound from "../pages/NotFound";
import Product from "../pages/Product";
import Profile from "../pages/Profile";
import User from "../pages/User";
// import HomeRecommend from "../pages/HomeRecommend";
// import HomeRanking from "../pages/HomeRanking";

const HomeRecommend = React.lazy(() => import("../pages/HomeRecommend"))
const HomeRanking = React.lazy(() => import("../pages/HomeRanking"))

const routes = [
  {
    path: "/",
    element: <Navigate to="/home"/>
  },
  {
    path: "/home",
    element: <Home/>,
    children: [
      {
        path: "/home/recommend",
        element: <HomeRecommend/>
      },
      {
        path: "/home/ranking",
        element: <HomeRanking/>
      },
    ]
  },
  {
    path: "/about",
    element: <About/>
  },
  {
    path: "profile",
    element: <Profile/>
  },
  {
    path: "/login",
    element: <Login/>
  },
  {
    path: "/product",
    element: <Product/>
  },
  {
    path: "/detail/:id",
    element: <Detail/>
  },
  {
    path: "/user",
    element: <User/>
  },
  {
    path: "*",
    element: <NotFound/>
  }
]

export default routes
