import classNames from 'classnames'
import React, { PureComponent } from 'react'
import { Link, Navigate, NavLink, Route, Routes, useNavigate, useRoutes } from 'react-router-dom'
import "./style.css"
import About from './pages/About'
import Home from './pages/Home'
import HomeRecommend from "./pages/HomeRecommend"
import HomeRanking from "./pages/HomeRanking"
import Profile from './pages/Profile'
import Login from './pages/Login'
import NotFound from './pages/NotFound'
import Product from './pages/Product'
import Detail from './pages/Detail'
import User from './pages/User'
import routes from './router'

export function App(props) {
  const navigate = useNavigate()

  function navigateToProduct() {
    navigate("/product")
  }

  return (
    <div className='app'>
      <div className='header'>
        <span><NavLink reloadDocument={true} to="">首页</NavLink></span>
        <NavLink to="about">关于</NavLink>
        <NavLink to="profile">我的</NavLink>
        <Link to="detail/123">详情:123</Link>
        <Link to="detail/321">详情:321</Link>
        <Link to="user?name=why&age=18">用户信息</Link>
        <button onClick={navigateToProduct}>商场</button>
      </div>
      {/* <Routes>
        <Route path="/" element={<Navigate to="/home"/>}/>
        <Route path='/home' element={<Home/>}>
          <Route path="/home" element={<Navigate to="/home/recommend"/>}/>
          <Route path="/home/recommend" element={<HomeRecommend/>}/>
          <Route path="/home/ranking" element={<HomeRanking/>}/>
        </Route>
        <Route path='/about' element={<About/>}/>
        <Route path='/profile' element={<Profile/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/product' element={<Product/>}/>
        <Route path='/detail/:id' element={<Detail/>}/>
        <Route path='/user' element={<User/>}/>
        <Route path='*' element={<NotFound/>}/>
      </Routes> */}

      <div>{useRoutes(routes)}</div>
      
      <div className='footer'>footer</div>
    </div>
  )
}

export default App
