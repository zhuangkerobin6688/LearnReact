import React, { PureComponent } from 'react'

export class HomeRecommend extends PureComponent {
  render() {
    return (
      <div>
        <h2>Home Recommend</h2>
        <ul>
          <li>推荐歌单1</li>
          <li>推荐歌单2</li>
          <li>推荐歌单3</li>
          <li>推荐歌单4</li>
          <li>推荐歌单5</li>
        </ul>
      </div>
    )
  }
}

export default HomeRecommend