import React, { PureComponent } from 'react'

export class Login extends PureComponent {
  render() {
    return (
      <div>
        <h2>Login Page</h2>
      </div>
    )
  }
}

export default Login