import React, { PureComponent } from 'react'

export class NotFound extends PureComponent {
  render() {
    return (
      <div>
        <h1>Not Found</h1>
        <p>输入路径没有对应的页面, 请检查后查看!</p>
      </div>
    )
  }
}

export default NotFound