import React, { PureComponent } from 'react'
import withRouter from '../hooks/withRouter'

export class User extends PureComponent {
  render() {
    const query = this.props.router.query

    return (
      <div>
        <h1>User Page:{query.name}-{query.age}</h1>
      </div>
    )
  }
}

export default withRouter(User)
