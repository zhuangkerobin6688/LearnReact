import React, { PureComponent } from 'react'
import withRouter from '../hooks/withRouter'

export class Detail extends PureComponent {
  render() {
    const params = this.props.router.params

    return (
      <div>
        <h1>Detail Page</h1>
        <h2>params: {params.id}</h2>
      </div>
    )
  }
}

export default withRouter(Detail)
