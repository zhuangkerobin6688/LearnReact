import hyRequest from "./request"


export default hyRequest
