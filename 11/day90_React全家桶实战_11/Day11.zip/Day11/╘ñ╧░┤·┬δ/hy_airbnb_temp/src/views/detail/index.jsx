import React, { memo } from 'react'

const Detail = memo((props) => {
  return (
    <div>Detail</div>
  )
})

Detail.propTypes = {}

export default Detail