import styled from "styled-components";

export const LongForWrapper = styled.div`
  .longfor-list {
    margin: 0 -8px;
  }
`