import React, { PureComponent } from 'react'

export class Order extends PureComponent {
  render() {
    return (
      <div>
        <h1>Order Page</h1>
      </div>
    )
  }
}

export default Order  