import React, { PureComponent } from 'react'
import "./Profle.css"

export class Profile extends PureComponent {
  render() {
    return (
      <div>
        <div className='section'>
          Profile Section
        </div>
      </div>
    )
  }
}

export default Profile