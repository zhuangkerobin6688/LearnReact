import styled from "styled-components";

export const SectionV2Wrapper = styled.div`
  margin-top: 30px;
`