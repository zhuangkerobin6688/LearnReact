export function isEmptyO(obj) {
  return !!Object.keys(obj).length
}