import React, { PureComponent, createRef } from 'react'
import "./animation/home.css"

import { CSSTransition, SwitchTransition, TransitionGroup } from "react-transition-group"

export class Home extends PureComponent {
  constructor(props) {
    super(props)
    this.state = {
      isShow: true,
      isLogin: true,
      friends: [
        {id: 111, name: "why", age: 18},
        {id: 112, name: "kobe", age: 20},
        {id: 113, name: "james", age: 30},
      ]
    }

    this.titleRef = createRef()
  }

  changeShow() {
    this.setState({ isShow: !this.state.isShow })
  }

  addFriend() {
    const friends = [...this.state.friends]
    friends.push({ id: new Date().getTime(), name: "curry", age: 30 })
    this.setState({ friends })
  }

  removeFriend(index) {
    const friends = [...this.state.friends]
    friends.splice(index, 1)
    this.setState({ friends })
  }

  render() {
    const { isShow, isLogin, friends } = this.state

    return (
      <div>
        <button onClick={e => this.changeShow()}>切换</button>
        <CSSTransition 
          in={isShow}
          nodeRef={this.titleRef}
          unmountOnExit={true}
          timeout={1000} 
          classNames="fade"
          appear
          onEnter={el => console.log("开始进入")}
          onEntering={el => console.log("正在进入")}
          onEntered={el => console.log("进入完成")}
          onExit={el => console.log("开始退出")}
          onExiting={el => console.log("正在退出")}
          onExited={el => console.log("退出完成")}
          >
          <h2 ref={this.titleRef}>你好啊,李银河</h2>
        </CSSTransition>

        <SwitchTransition mode='out-in'>
          <CSSTransition
            key={isLogin ? "登录": "注册"}
            classNames="fade"
            timeout={1000}
          >
            <button>{ isLogin ? "登录": "注册" }</button>
          </CSSTransition>
        </SwitchTransition>
        <button onClick={e => this.setState({ isLogin: !isLogin })}>切换</button>

        <TransitionGroup component="ul">
          {
            friends.map((item, index) => {
              return (
                <CSSTransition
                  key={item.id}
                  classNames="item"
                  timeout={1000}
                >
                  <li>
                    <span>{item.name}-{item.age}</span>
                    <button onClick={e => this.removeFriend(index)}>删除</button>
                  </li>
                </CSSTransition>
              )
            })
          }
        </TransitionGroup>
        <button onClick={e => this.addFriend()}>添加好友</button>
      </div>
    )
  }
}

export default Home