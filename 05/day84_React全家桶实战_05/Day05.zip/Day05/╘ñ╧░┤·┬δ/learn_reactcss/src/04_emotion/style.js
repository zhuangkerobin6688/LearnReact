import styled from "@emotion/styled"

export const FiveWrapper = styled.div`
  border: 1px solid black;

  .title {
    font-size: 36px;
    color: blueviolet;
  }

  .content {
    font-size: 24px;
    color: royalblue;
  }
`
