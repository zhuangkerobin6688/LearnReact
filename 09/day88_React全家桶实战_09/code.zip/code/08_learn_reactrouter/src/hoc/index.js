import withRouter from "./with_router";


export {
  withRouter
}
