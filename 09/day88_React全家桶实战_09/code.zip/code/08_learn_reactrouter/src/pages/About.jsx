import React, { PureComponent } from 'react'

export class About extends PureComponent {
  render() {
    return (
      <div>
        <h1>About Page</h1>
      </div>
    )
  }
}

export default About