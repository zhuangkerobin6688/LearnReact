export const BASE_URL = "http://codercba.com:1888/toutiao/api"
export const TIMEOUT = 10000