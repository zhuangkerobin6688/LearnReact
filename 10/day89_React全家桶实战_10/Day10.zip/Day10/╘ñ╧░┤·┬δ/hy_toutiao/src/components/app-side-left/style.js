import styled from 'styled-components'

export const AppLeft = styled.div`
  width: 676px;
`