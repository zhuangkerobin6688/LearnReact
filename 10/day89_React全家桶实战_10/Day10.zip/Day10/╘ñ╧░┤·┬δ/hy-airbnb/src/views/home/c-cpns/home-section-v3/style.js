import styled from 'styled-components'


export const SectionWrapper = styled.div`
  margin-top: 36px;
`
