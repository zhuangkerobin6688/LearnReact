import styled from "styled-components"

export const DetailWrapper = styled.div`

`
