import styled from 'styled-components'

// const ContentWrapper = css`
//   width: 1032px;
//   margin: 0 auto;
// `

export const DiscountWrapper = styled.div`
  margin-top: 40px;
`
