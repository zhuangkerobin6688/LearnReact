export const CHANGE_HOUSE_LIST = "entire/change_house_list"
export const CHANGE_TOTAL_COUNT = "entire/change_total_count"
export const CHANGE_CURRENT_PAGE = "entire/change_current_page"
