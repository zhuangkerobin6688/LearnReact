import React, { memo } from 'react'

const Detail = memo(() => {
  return (
    <div>Detail</div>
  )
})

export default Detail
